let data = [];
let selectedAirport = 'All';
let selectedWeather = ['Rain', 'Wind', 'Snow'];
let selectedMonth = 'All';

const margin = { top: 40, right: 40, bottom: 60, left: 60 };

function getResponsiveSize() {
  const container = document.querySelector('.center-area');
  const width = Math.min((container ? container.clientWidth : window.innerWidth) - 60, 900);
  const height = 380;
  return { width, height };
}

// ---- LOAD CSV DATA ----
d3.csv('flights_weather_JFK_EWR_ATL_clean.csv').then(raw => {
  const records = [];
  raw.forEach(d => {
    const airport = d.airport_code?.trim();
    const dateStr = d.date || d.FL_DATE;
    if (!dateStr) return;
    const date = new Date(dateStr.split('-').reverse().join('-'));
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const rain = +d.rain_flag || 0;
    const snow = +d.snow_flag || 0;
    const wind = +d.windy_flag || 0;
    const arrDelay = +d.arr_delay_15m || 0;
    const depDelay = +d.dep_delay_15m || 0;
    const delay = Math.max(arrDelay, depDelay);
    if (rain === 1) records.push({ airport, year, month, weather: 'Rain', delay });
    if (snow === 1) records.push({ airport, year, month, weather: 'Snow', delay });
    if (wind === 1) records.push({ airport, year, month, weather: 'Wind', delay });
  });

  data = d3.rollups(
    records,
    v => 100 * d3.mean(v, d => d.delay),
    d => `${d.airport}-${d.year}-${d.month}-${d.weather}`
  ).map(([key, delay_pct]) => {
    const [airport, year, month, weather] = key.split('-');
    return { airport, year: +year, month: +month, weather, delay_pct: +delay_pct, date: new Date(+year, +month - 1, 1) };
  });

  initUI();
  updateCharts();
});

// ---- CONTROLS ----
function initUI() {
  const airports = ['All', ...new Set(data.map(d => d.airport))];
  d3.select('#airportDropdown').selectAll('option').data(airports)
    .join('option').text(d => d).attr('value', d => d);

  d3.select('#airportDropdown').on('change', e => { selectedAirport = e.target.value; updateCharts(); });
  d3.selectAll('input.weather-toggle').on('change', e => {
    const w = e.target.value;
    if (e.target.checked) { if (!selectedWeather.includes(w)) selectedWeather.push(w); }
    else selectedWeather = selectedWeather.filter(v => v !== w);
    updateCharts();
  });

  d3.selectAll('.quickview').on('click', e => {
    const weather = e.target.dataset.weather;
    selectedWeather = [weather];
    d3.selectAll('input.weather-toggle').property('checked', false);
    d3.select(`input[value="${weather}"]`).property('checked', true);
    updateCharts();
  });

  d3.select('#monthDropdown').on('change', e => { selectedMonth = e.target.value; updateCharts(); });
}

// ---- TOOLTIP ----
const tooltip = d3.select('body').append('div')
  .attr('id', 'tooltip')
  .style('position', 'absolute')
  .style('visibility', 'hidden')
  .style('background', 'rgba(255,255,255,0.95)')
  .style('border', '1px solid #aaa')
  .style('border-radius', '6px')
  .style('padding', '8px 12px')
  .style('font-size', '0.85em')
  .style('box-shadow', '0 2px 6px rgba(0,0,0,0.2)');

// ---- UPDATE CHARTS ----
function updateCharts() {
  const { width, height } = getResponsiveSize();
  if (!data || data.length === 0) return;

  let view = data.filter(
    d => (selectedAirport === 'All' || d.airport === selectedAirport) &&
         selectedWeather.includes(d.weather)
  );
  if (selectedMonth !== 'All') {
    const m = new Date(`${selectedMonth} 1, 2020`).getMonth() + 1;
    view = view.filter(d => d.month === m);
  }

  // ===== BAR CHART =====
  const barSvg = d3.select('#barChart')
    .attr('viewBox', `0 0 ${width} ${height + 50}`)
    .attr('preserveAspectRatio', 'xMidYMid meet');
  barSvg.selectAll('*').remove();

  const x0 = d3.scaleBand().domain(selectedWeather).range([margin.left, width - margin.right]).padding(0.25);
  const airports = ['ATL', 'EWR', 'JFK'];
  const x1 = d3.scaleBand().domain(airports).range([0, x0.bandwidth()]).padding(0.05);
  const y = d3.scaleLinear().domain([0, d3.max(view, d => d.delay_pct) || 10]).nice().range([height - margin.bottom, margin.top]);
  const color = d3.scaleOrdinal().domain(airports).range(['#1f77b4', '#ff7f0e', '#2ca02c']);

  barSvg.append('g').attr('transform', `translate(0,${height - margin.bottom})`).call(d3.axisBottom(x0));
  barSvg.append('g').attr('transform', `translate(${margin.left},0)`).call(d3.axisLeft(y));

  const bars = barSvg.append('g').selectAll('g').data(selectedWeather).join('g')
    .attr('transform', d => `translate(${x0(d)},0)`)
    .selectAll('rect').data(d => view.filter(v => v.weather === d)).join('rect')
    .attr('x', d => x1(d.airport)).attr('y', height - margin.bottom)
    .attr('width', x1.bandwidth()).attr('height', 0).attr('fill', d => color(d.airport));

  bars.transition().duration(3000).ease(d3.easeCubicOut)
    .attr('y', d => y(d.delay_pct)).attr('height', d => y(0) - y(d.delay_pct))
    .on('end', (_, i, nodes) => { if (i === nodes.length - 1) enableBarHover(); });

  function enableBarHover() {
    barSvg.selectAll('rect')
      .on('mouseover', function (e, d) {
        tooltip.style('visibility', 'visible')
          .html(`<b>${d.weather}</b><br>${d.airport}<br>${d.delay_pct.toFixed(1)}% delayed`);
        let insight = `✈️ At <b>${d.airport}</b>, approximately <b>${d.delay_pct.toFixed(1)}%</b> of flights were delayed under <b>${d.weather}</b> conditions.`;
        if (d.airport === 'JFK') insight += ` This indicates that <b>John F. Kennedy International</b> faces more severe disruptions, especially during <b>${d.weather.toLowerCase()}</b> events.`;
        if (d.airport === 'ATL') insight += ` <b>Atlanta’s</b> performance remains relatively stable across weather types, suggesting resilient scheduling practices.`;
        if (d.airport === 'EWR') insight += ` <b>Newark Liberty</b> shows moderate vulnerability, balancing between JFK’s extremes and ATL’s stability.`;
        d3.select('#barAnnotation').html(insight);
        barSvg.selectAll('rect:not(.legend-item)').transition().duration(150).attr('opacity', 0.3);
        d3.select(this).raise().transition().duration(150).attr('opacity', 1).attr('stroke', '#000').attr('stroke-width', 1.2);
      })
      .on('mousemove', e => tooltip.style('top', (e.pageY - 35) + 'px').style('left', (e.pageX + 15) + 'px'))
      .on('mouseout', function () {
        tooltip.style('visibility', 'hidden');
        d3.select('#barAnnotation').text('💡 Hover over bars to view delay distribution by airport.');
        barSvg.selectAll('rect').transition().duration(150).attr('opacity', 1).attr('stroke', 'none');
      });
  }

  //  BAR LEGEND RESTORED
  const legendData = [
    { airport: 'ATL', color: '#1f77b4' },
    { airport: 'EWR', color: '#ff7f0e' },
    { airport: 'JFK', color: '#2ca02c' }
  ];
  const legend = barSvg.append('g').attr('transform', `translate(${width / 2 - 120}, ${margin.top - 25})`);
  legend.selectAll('rect').data(legendData).join('rect')
    .attr('class', 'legend-item')
    .attr('x', (d, i) => i * 100).attr('width', 14).attr('height', 14)
    .attr('fill', d => d.color).attr('stroke', '#444').attr('rx', 3).attr('ry', 3);
  legend.selectAll('text').data(legendData).join('text')
    .attr('x', (d, i) => i * 100 + 20).attr('y', 11)
    .attr('font-size', '0.9em').attr('fill', '#111').text(d => d.airport);

  // ===== LINE CHART =====
  const lineSvg = d3.select('#lineChart')
    .attr('viewBox', `0 0 ${width} 300`)
    .attr('preserveAspectRatio', 'xMidYMid meet');
  lineSvg.selectAll('*').remove();

  if (!view.length) return;
  const x = d3.scaleTime().domain(d3.extent(view, d => d.date)).range([margin.left, width - margin.right]);
  const y2 = d3.scaleLinear().domain([0, d3.max(view, d => d.delay_pct) || 10]).nice().range([300 - margin.bottom, margin.top]);
  const color2 = d3.scaleOrdinal().domain(['Rain', 'Wind', 'Snow']).range(['#1f77b4', '#d62728', '#9467bd']);

  lineSvg.append('g').attr('transform', `translate(0,${300 - margin.bottom})`)
    .call(d3.axisBottom(x).ticks(8).tickFormat(d3.timeFormat('%b %Y')));
  lineSvg.append('g').attr('transform', `translate(${margin.left},0)`).call(d3.axisLeft(y2));

  const line = d3.line().x(d => x(d.date)).y(d => y2(d.delay_pct)).curve(d3.curveMonotoneX);
  const grouped = d3.groups(view, d => d.weather);

  lineSvg.selectAll('.line-path').data(grouped).join('path')
    .attr('fill', 'none').attr('stroke', d => color2(d[0])).attr('stroke-width', 2)
    .attr('d', d => line(d[1].sort((a, b) => a.date - b.date)))
    .attr('stroke-dasharray', function () { const l = this.getTotalLength(); return `${l} ${l}`; })
    .attr('stroke-dashoffset', function () { return this.getTotalLength(); })
    .transition().duration(3000).ease(d3.easeCubicOut).attr('stroke-dashoffset', 0);

  const circles = lineSvg.selectAll('circle').data(view).join('circle')
    .attr('cx', d => x(d.date)).attr('cy', d => y2(d.delay_pct))
    .attr('r', 0).attr('fill', d => color2(d.weather)).style('cursor', 'pointer');
  circles.transition().delay(3000).duration(800).attr('r', 4).on('end', () => {
    lineSvg.selectAll('circle')
      .on('mouseover', function (e, d) {
        tooltip.style('visibility', 'visible')
          .html(`<b>${d3.timeFormat('%B %Y')(d.date)}</b><br>${d.weather}: ${d.delay_pct.toFixed(1)}% delayed`);
        d3.select('#lineAnnotation').html(
          `📈 In <b>${d3.timeFormat('%B %Y')(d.date)}</b>, <b>${d.weather}</b>-related delays reached <b>${d.delay_pct.toFixed(1)}%</b>. 
           This suggests a noticeable seasonal spike, with <b>${d.weather.toLowerCase()}</b> showing stronger influence on flight punctuality.`
        );
        lineSvg.selectAll('circle').transition().duration(150).attr('opacity', 0.3);
        d3.select(this).raise().transition().duration(150).attr('opacity', 1)
          .attr('r', 8).attr('stroke', '#000').attr('stroke-width', 2);
      })
      .on('mousemove', e => tooltip.style('top', (e.pageY - 35) + 'px').style('left', (e.pageX + 15) + 'px'))
      .on('mouseout', function () {
        tooltip.style('visibility', 'hidden');
        d3.select('#lineAnnotation').text('💡 Hover over the trend line to reveal key monthly insights.');
        lineSvg.selectAll('circle').transition().duration(150).attr('opacity', 1);
        d3.select(this).transition().duration(150).attr('r', 4).attr('stroke', 'none');
      });
  });

  // LINE LEGEND 
  const lineLegendData = [
    { weather: 'Rain', color: '#1f77b4' },
    { weather: 'Wind', color: '#d62728' },
    { weather: 'Snow', color: '#9467bd' }
  ];
  const lineLegend = lineSvg.append('g').attr('transform', `translate(${width / 2 - 150}, ${margin.top - 20})`);
  lineLegend.selectAll('rect').data(lineLegendData).join('rect')
    .attr('x', (d, i) => i * 100).attr('width', 14).attr('height', 14)
    .attr('fill', d => d.color).attr('stroke', '#444').attr('rx', 3).attr('ry', 3);
  lineLegend.selectAll('text').data(lineLegendData).join('text')
    .attr('x', (d, i) => i * 100 + 20).attr('y', 11)
    .attr('font-size', '0.9em').attr('fill', '#111').text(d => d.weather);

  // ===== HEATMAP =====
  const heatSvg = d3.select('#heatmapChart')
    .attr('viewBox', `0 0 ${width} 320`)
    .attr('preserveAspectRatio', 'xMidYMid meet');
  heatSvg.selectAll('*').remove();

  const heatData = d3.rollups(view, v => d3.mean(v, d => d.delay_pct), d => d.airport, d => d.weather)
    .flatMap(([airport, list]) => list.map(([weather, delay]) => ({ airport, weather, delay })));

  const xHeat = d3.scaleBand().domain(selectedWeather).range([margin.left, width - margin.right]).padding(0.1);
  const yHeat = d3.scaleBand().domain(['ATL', 'EWR', 'JFK']).range([margin.top + 30, 260]).padding(0.1);
  const colorHeat = d3.scaleSequential().domain([0, d3.max(heatData, d => d.delay) || 10]).interpolator(d3.interpolateYlOrRd);

  heatSvg.append('g').attr('transform', `translate(0,${260})`).call(d3.axisBottom(xHeat));
  heatSvg.append('g').attr('transform', `translate(${margin.left},0)`).call(d3.axisLeft(yHeat));

  heatSvg.selectAll('.cell').data(heatData).join('rect')
    .attr('class', 'cell').attr('x', d => xHeat(d.weather)).attr('y', d => yHeat(d.airport))
    .attr('width', xHeat.bandwidth()).attr('height', yHeat.bandwidth())
    .attr('fill', '#fff').style('opacity', 0)
    .transition().duration(3000).ease(d3.easeCubicOut)
    .attr('fill', d => d.delay ? colorHeat(d.delay) : '#eee').style('opacity', 1)
    .on('end', () => {
      heatSvg.selectAll('.cell')
        .on('mouseover', function (e, d) {
          tooltip.style('visibility', 'visible')
            .html(`<b>${d.airport}</b><br>${d.weather}: ${d.delay?.toFixed(1) || 0}% delayed`);
          d3.select('#heatAnnotation').html(
            `🌦️ <b>${d.airport}</b> recorded an average delay of <b>${d.delay?.toFixed(1) || 0}%</b> under <b>${d.weather}</b> conditions. 
             This pattern suggests that ${d.airport === 'JFK' ? '<b>JFK</b> faces harsher winter disruptions' : d.airport === 'ATL' ? '<b>Atlanta</b> experiences minimal seasonal impact' : '<b>Newark</b> balances moderate variability between rain and wind.'}`
          );
          heatSvg.selectAll('.cell').transition().duration(150).attr('opacity', 0.3);
          d3.select(this).raise().transition().duration(150).attr('opacity', 1)
            .attr('stroke', '#000').attr('stroke-width', 2);
        })
        .on('mousemove', e => tooltip.style('top', (e.pageY - 35) + 'px').style('left', (e.pageX + 15) + 'px'))
        .on('mouseout', function () {
          tooltip.style('visibility', 'hidden');
          d3.select('#heatAnnotation').text('💡 Hover over cells to explore average delay percentages by airport and weather.');
          heatSvg.selectAll('.cell').transition().duration(150).attr('opacity', 1).attr('stroke', 'none');
        });
    });

  // HEATMAP COLOR SCALE
  const scaleWidth = 160, scaleHeight = 10, scaleY = 5, labelGap = 25;
  const defs = heatSvg.append('defs');
  const gradient = defs.append('linearGradient').attr('id', 'heatmapScale').attr('x1', '0%').attr('x2', '100%');
  gradient.append('stop').attr('offset', '0%').attr('stop-color', d3.interpolateYlOrRd(0));
  gradient.append('stop').attr('offset', '100%').attr('stop-color', d3.interpolateYlOrRd(1));

  heatSvg.append('rect')
    .attr('x', width / 2 - scaleWidth / 2)
    .attr('y', scaleY)
    .attr('width', scaleWidth)
    .attr('height', scaleHeight)
    .style('fill', 'url(#heatmapScale)')
    .attr('stroke', '#555')
    .attr('rx', 2)
    .attr('ry', 2);

  heatSvg.append('text')
    .attr('x', width / 2 - scaleWidth / 2 - 25)
    .attr('y', scaleY + labelGap)
    .attr('font-size', '0.8em')
    .text('Low');

  heatSvg.append('text')
    .attr('x', width / 2 + scaleWidth / 2 + 25)
    .attr('y', scaleY + labelGap)
    .attr('font-size', '0.8em')
    .attr('text-anchor', 'end')
    .text('High');
}

// Responsive redraw
window.addEventListener('resize', () => {
  clearTimeout(window._resizeTimer);
  window._resizeTimer = setTimeout(updateCharts, 500);
});
