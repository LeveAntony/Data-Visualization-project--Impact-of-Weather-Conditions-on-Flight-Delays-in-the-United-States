🔧 Viewing Instructions
-----------------------
To properly view the interactive dashboard and load the dataset, please run the HTML file using a local web server.

Option 1 (Recommended – VS Code):
1. Open the project folder in Visual Studio Code.
2. Right-click on "index.html" → select "Open with Live Server".
3. The dashboard will open automatically in your default browser with full data.

Option 2 (Alternative – Command Line):
1. Open the project folder in Terminal / Command Prompt.
2. Run:  python -m http.server 8000
3. Visit http://localhost:8000 in your browser. ( local host may be diffrent for ur pc ) 

Note:
Double-clicking "index.html" directly (file:// path) will not display the data because browsers block local CSV file access for security reasons.
